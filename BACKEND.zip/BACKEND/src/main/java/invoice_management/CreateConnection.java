package invoice_management;

import java.sql.Connection;
import java.sql.DriverManager;

public class CreateConnection {
	static Connection cnc;   //static doesn't require object call

	public static Connection getCnc() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String user = "root";
			String password = "ROOT";
			String url = "jdbc:mysql://localhost:3306/grey_goose";
			cnc = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			System.out.println(e);
		}
		return cnc;
	}

}
