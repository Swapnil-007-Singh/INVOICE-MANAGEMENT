package invoice_management;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.apache.catalina.User;

import com.google.gson.Gson;

//import pojo.USER;

@WebServlet("/Delete")
public class Delete extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Delete() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HashMap<Object, Object> Response = new HashMap<Object, Object>();

		try {

			String sl_no = request.getParameter("sl_no");

			Connection cnc = CreateConnection.getCnc();
			String Query = "DELETE FROM winter_internship WHERE sl_no = ? ";
			PreparedStatement pst = cnc.prepareStatement(Query);
			pst.setString(1, sl_no);

			if (pst.executeUpdate() > 0) {
				Response.put("delete", true);
			} else {
				Response.put("delete", false);
			}

			Gson gson = new Gson();
			String response_Json = gson.toJson(Response);

			response.setHeader("Access-Control-Allow-Origin", "*");
			response.getWriter().append(response_Json);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

}
