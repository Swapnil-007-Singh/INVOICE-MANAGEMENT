package invoice_management;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import pojo.USER;

/**
 * Servlet implementation class AdvanceSearch
 */
@WebServlet("/AdvanceSearch")
public class AdvanceSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AdvanceSearch() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		HashMap<Object, Object> Response = new HashMap<Object, Object>();
		ArrayList<USER> Customers = new ArrayList<USER>();

		try {
			String doc_id = request.getParameter("doc_id");
			String invoice_id = request.getParameter("invoice_id");
			String cust_number = request.getParameter("cust_number");
			String buisness_year = request.getParameter("buisness_year");

			Connection cnc = CreateConnection.getCnc();

			String query = "SELECT * FROM winter_internship WHERE doc_id=? AND invoice_id=? AND cust_number=? AND buisness_year=?";

			PreparedStatement pst = cnc.prepareStatement(query);

			pst.setString(1, doc_id);
			pst.setString(2, invoice_id);
			pst.setString(3, cust_number);
			pst.setString(4, buisness_year);

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				USER customer = new USER(rs.getString("sl_no"), rs.getString("business_code"),
						rs.getString("cust_number"), rs.getString("clear_date"), rs.getString("buisness_year"),
						rs.getString("doc_id"), rs.getString("posting_date"), rs.getString("document_create_date"),
						rs.getString("due_in_date"), rs.getString("invoice_currency"), rs.getString("document_type"),
						rs.getString("posting_id"), rs.getString("total_open_amount"),
						rs.getString("baseline_create_date"), rs.getString("cust_payment_terms"),
						rs.getString("invoice_id"));
				Customers.add(customer);

			}
			Response.put("customers", Customers);
		} catch (Exception e) {
			System.out.println(e);
		}
		Gson gson = new Gson();
		String response_Json = gson.toJson(Response);
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.getWriter().append(response_Json);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
