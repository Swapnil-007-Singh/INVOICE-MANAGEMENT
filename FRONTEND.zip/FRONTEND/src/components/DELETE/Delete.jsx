import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import DialogActions from "@mui/material/DialogActions";

export default function Delete({
  delopen,
  handleClickDelOpen,
  handleDelClose,
}) {
  return (
    <div>
      <Button
        style={{ color: "white", width: "11vw" }}
        variant="outlined"
        onClick={handleClickDelOpen}
      >
        DELETE
      </Button>
      <Dialog open={delopen} onClose={handleDelClose}>
        <DialogTitle style={{ backgroundColor: "#273d4a", color: "white" }}>
          Delete Records?
        </DialogTitle>
        <DialogContent style={{ backgroundColor: "#273d4a" }}>
          <DialogContentText style={{ color: "white" }}>
            Are you sure want to delete these record[s]?
          </DialogContentText>
        </DialogContent>
        <DialogActions style={{ backgroundColor: "#273d4a" }}>
          <Button
            variant="outlined"
            style={{ color: "white", width: "500px", borderColor: "white" }}
            onClick={() => handleDelClose(true)}
          >
            Delete
          </Button>
          <Button
            variant="outlined"
            style={{ color: "white", width: "500px", borderColor: "white" }}
            onClick={() => handleDelClose(false)}
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
