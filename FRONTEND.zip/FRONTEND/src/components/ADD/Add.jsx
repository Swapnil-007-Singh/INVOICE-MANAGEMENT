import React, { useEffect, useState } from "react";
import Button from "@mui/material/Button";
import { addCust, getData } from "../../services/data";
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  TextField,
} from "@mui/material";
// import "./Add.css";

import { makeStyles } from "@material-ui/core/styles";
import Box from "@mui/material/Box";

const useStyles = makeStyles(() => ({
  textField: {
    margin: 9,
    width: "31ch",
    background: "rgb(232, 249, 250)",
    borderRadius: "4px",
  },
}));

function Add() {
  const classes = useStyles();

  const [user, setUser] = useState({
    business_code: "",
    cust_number: "",
    clear_date: "",
    buisness_year: "",
    doc_id: "",
    posting_date: "",
    document_create_date: "",
    due_in_date: "",
    invoice_currency: "",
    document_type: "",
    posting_id: "",
    total_open_amount: "",
    baseline_create_date: "",
    cust_payment_terms: "",
    invoice_id: "",
  });

  const {
    business_code,
    cust_number,
    clear_date,
    buisness_year,
    doc_id,
    posting_date,
    document_create_date,
    due_in_date,
    invoice_currency,
    document_type,
    posting_id,
    total_open_amount,
    baseline_create_date,
    cust_payment_terms,
    invoice_id,
  } = user;

  const changeHandler = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  const submitHandler = async (e) => {
    e.preventDefault(); // prevents page from auto-reloading
    let response = addCust(user); //addCust=> API call of add from backend
    if (response) {
      setUser({
        business_code: "",
        cust_number: "",
        clear_date: "",
        buisness_year: "",
        doc_id: "",
        posting_date: "",
        document_create_date: "",
        due_in_date: "",
        invoice_currency: "",
        document_type: "",
        posting_id: "",
        total_open_amount: "",
        baseline_create_date: "",
        cust_payment_terms: "",
        invoice_id: "",
      });
    }
    handleClose(); //closes dialog box
  };

  // Display new added data
  const [data, setData] = useState([]);
  useEffect(async () => setData(await getData()), []);

  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const clickClose = () => {
    setOpen(false);
  };

  return (
    <>
      <div>
        <Button
          variant="outlined"
          style={{ color: "white", width: "10vw" }}
          onClick={handleClickOpen}
        >
          ADD
        </Button>
        <Dialog fullWidth maxWidth="lg" open={open} onClose={handleClose}>
          <Box
            component="form"
            sx={{
              display: "flex",
              flexWrap: "wrap",
              backgroundColor: "#273D4A",
              color: "white",
            }}
            noValidate
            autoComplete="off"
          >
            <DialogTitle>ADD</DialogTitle>
            <DialogContent>
              <TextField
                className={classes.textField}
                type="text"
                name="business_code"
                value={business_code}
                onChange={changeHandler}
                variant="filled"
                label="Business Code"
              />
              <TextField
                className={classes.textField}
                type="text"
                name="cust_number"
                value={cust_number}
                onChange={changeHandler}
                variant="filled"
                label="Customer Number"
              />
              <TextField
                className={classes.textField}
                type="date"
                name="clear_date"
                value={clear_date}
                onChange={changeHandler}
                variant="filled"
                label="Clear Date"
              />
              <TextField
                className={classes.textField}
                type="text"
                name="buisness_year"
                value={buisness_year}
                onChange={changeHandler}
                variant="filled"
                label="Business Year"
              />

              <TextField
                className={classes.textField}
                type="text"
                name="doc_id"
                value={doc_id}
                onChange={changeHandler}
                variant="filled"
                label="Document Id"
              />
              <TextField
                className={classes.textField}
                type="date"
                name="posting_date"
                value={posting_date}
                onChange={changeHandler}
                variant="filled"
                label="Posting Date"
              />
              <TextField
                className={classes.textField}
                type="date"
                name="document_create_date"
                value={document_create_date}
                onChange={changeHandler}
                variant="filled"
                label="Document Create Date"
              />
              <TextField
                className={classes.textField}
                type="date"
                name="due_in_date"
                value={due_in_date}
                onChange={changeHandler}
                variant="filled"
                label="Due Date"
              />

              <TextField
                className={classes.textField}
                type="text"
                name="invoice_currency"
                value={invoice_currency}
                onChange={changeHandler}
                variant="filled"
                label="Invoice Currency"
              />
              <TextField
                className={classes.textField}
                type="text"
                name="document_type"
                value={document_type}
                onChange={changeHandler}
                variant="filled"
                label="Document Type"
              />
              <TextField
                className={classes.textField}
                type="text"
                name="posting_id"
                value={posting_id}
                onChange={changeHandler}
                variant="filled"
                label="Posting Id"
              />
              <TextField
                className={classes.textField}
                type="text"
                name="total_open_amount"
                value={total_open_amount}
                onChange={changeHandler}
                variant="filled"
                label="Total Open Amount"
              />

              <TextField
                className={classes.textField}
                type="date"
                name="baseline_create_date"
                value={baseline_create_date}
                variant="filled"
                onChange={changeHandler}
                label="Baseline Create Date"
              />
              <TextField
                className={classes.textField}
                type="text"
                name="cust_payment_terms"
                value={cust_payment_terms}
                onChange={changeHandler}
                variant="filled"
                label="Cutomer Payment Terms"
              />
              <TextField
                className={classes.textField}
                type="text"
                name="invoice_id"
                value={invoice_id}
                onChange={changeHandler}
                variant="filled"
                label="Invoice Id"
              />
            </DialogContent>

            <DialogActions>
              <Button
                variant="outlined"
                style={{ color: "white", width: "583px", borderColor: "white" }}
                onClick={submitHandler}
              >
                Add
              </Button>
              <Button
                variant="outlined"
                style={{
                  color: "white",
                  width: "583px",
                  borderColor: "white",
                }}
                onClick={clickClose}
              >
                Cancel
              </Button>
            </DialogActions>
          </Box>
        </Dialog>
      </div>
    </>
  );
}
export default Add;
