import React, { useEffect, useState } from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import { DialogContent, TextField } from "@mui/material/";
import DialogTitle from "@mui/material/DialogTitle";
import { makeStyles } from "@material-ui/core/styles";
import Box from "@mui/material/Box";
import DialogActions from "@mui/material/DialogActions";

const useStyles = makeStyles(() => ({
  textField: {
    margin: 9,
    width: "31ch",
    background: "rgb(232, 249, 250)",
    borderRadius: "4px",
  },
}));

function Advance({
  cust_number,
  buisness_year,
  doc_id,
  invoice_id,
  changeAdvHandler,
  submitAdvHandler,
  advOpen,
  handleClickAdvOpen,
  handleAdvClose,
}) {
  const classes = useStyles();
  return (
    <div>
      <Button
        variant="outlined"
        style={{ color: "white", width: "11vw" }}
        onClick={handleClickAdvOpen}
      >
        ADVANCE SEARCH
      </Button>
      <Dialog fullWidth maxWidth="sm" open={advOpen} onClose={handleAdvClose}>
        <Box
          component="form"
          sx={{
            display: "flex",
            flexWrap: "wrap",
            backgroundColor: "#273D4A",
            color: "white",
          }}
          noValidate
          autoComplete="off"
        >
          <DialogTitle>Advance Search</DialogTitle>
          <DialogContent>
            <TextField
              autoFocus
              name="doc_id"
              id="doc_id"
              label="Document ID"
              type="text"
              onChange={changeAdvHandler}
              value={doc_id}
              variant="standard"
              className={classes.textField}
            />
            <TextField
              autoFocus
              name="invoice_id"
              id="invoice_id"
              label="Invoice ID"
              type="text"
              onChange={changeAdvHandler}
              value={invoice_id}
              variant="standard"
              className={classes.textField}
            />
            <TextField
              autoFocus
              name="cust_number"
              id="cust_number"
              label="Customer Number"
              type="text"
              onChange={changeAdvHandler}
              value={cust_number}
              variant="standard"
              className={classes.textField}
            />
            <TextField
              autoFocus
              name="buisness_year"
              id="buisness_year"
              label="Business Year"
              type="text"
              onChange={changeAdvHandler}
              value={buisness_year}
              variant="standard"
              className={classes.textField}
            />
          </DialogContent>
          <DialogActions>
            <Button
              variant="outlined"
              style={{ color: "white", width: "288px", borderColor: "white" }}
              onClick={submitAdvHandler}
            >
              Search
            </Button>
            <Button
              variant="outlined"
              style={{ color: "white", width: "288px", borderColor: "white" }}
              onClick={() => handleAdvClose(false)}
            >
              Cancel
            </Button>
          </DialogActions>
        </Box>
      </Dialog>
    </div>
  );
}

export default Advance;
