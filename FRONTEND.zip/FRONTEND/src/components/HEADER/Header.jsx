import React from "react";
import Logo1 from "./Logo1.svg";
import "./Header.css";

function Header() {
  return (
    <>
      <div className="overall">
        <div className="logo">
          <div className="logoF">
            <img src={Logo1} alt="" />
          </div>
        </div>
        <div className="invoice">
          <h2>Invoice List</h2>
        </div>
      </div>
    </>
  );
}

export default Header;
