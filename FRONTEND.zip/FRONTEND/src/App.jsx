import React from "react";
import Main from "./components/MAIN/Main";
import Header from "./components/HEADER/Header";
import Footer from "./components/FOOTER/Footer";

function App() {
  return (
    <>
      <Header />
      <Main />
      <Footer />
    </>
  );
}

export default App;
